This patch add gpio, i2c and netperf tools to ET1500.

1.copy patch archive file to ET1500 /tmp

2.tar -zxvf et1500-tools-update-p1.tar.gz

3.cd ./tools-update

4.sh tools-update.sh
