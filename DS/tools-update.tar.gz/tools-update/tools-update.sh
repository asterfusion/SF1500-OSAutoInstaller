#!/bin/bash
chmod 755 ./i2c*
chmod 755 ./gpioset
chmod 755 ./net*
cp ./i2c* $1/bin/
cp ./gpioset $1/bin/
cp ./net* $1/bin/
cp README.txt  $1/root/
echo "tools install success"
